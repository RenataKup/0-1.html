console.log('Renata', 35);
console.log('Renata' + 35);
console.log('is smalsumo');
console.log(' mano batai buvo du\n vienas dingo\n nerandu\n as su vienu batuku\n niekur eiti negaliu');
console.log('***');
console.log('* *');
console.log('***');
console.log('*');
console.log('**');
console.log('***');
console.log('+--------+-------+');
console.log('| Vardas | Amzius|');
console.log('+--------+-------+');
console.log('| Tomas  | 23    |');
console.log('| Nida   | 45    |');
console.log('| Kopa   | 33    |');
console.log('+--------+-------+')